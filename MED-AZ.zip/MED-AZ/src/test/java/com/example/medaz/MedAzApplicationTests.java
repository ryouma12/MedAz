package com.example.medaz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedAzApplicationTests {

    @Test
    void contextLoads() {
    }

}
