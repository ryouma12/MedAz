package com.example.medaz.entity;

public enum RoleName {
    ROLE_USER,
    ROLE_DOCTOR
}