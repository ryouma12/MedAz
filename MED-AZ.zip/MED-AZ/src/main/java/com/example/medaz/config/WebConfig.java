package com.example.medaz.config;

public class WebConfig {
}
